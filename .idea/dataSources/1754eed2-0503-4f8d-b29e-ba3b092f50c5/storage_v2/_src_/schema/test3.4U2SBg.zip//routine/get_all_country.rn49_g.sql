create
    definer = root@localhost procedure get_all_country()
BEGIN 
SELECT * FROM country;
END;

