create
    definer = root@localhost procedure update_city(IN id int, IN city_name varchar(255), IN nation varchar(100),
                                                   IN area double, IN danso bigint, IN gdp double, IN description text)
BEGIN 
UPDATE city
set city.city_name = city_name, city.nation = nation, city.area = area, city.danso = danso, city.gdp = gdp, city.description = description
where city.id = id;
END;

