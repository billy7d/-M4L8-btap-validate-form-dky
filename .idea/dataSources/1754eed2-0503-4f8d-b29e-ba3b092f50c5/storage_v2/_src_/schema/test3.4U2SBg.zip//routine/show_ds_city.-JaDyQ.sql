create
    definer = root@localhost procedure show_ds_city()
BEGIN 
SELECT * from city;
END;

