create
    definer = root@localhost procedure delete_city(IN id int)
BEGIN
DELETE FROM city where city.id =id;
END;

