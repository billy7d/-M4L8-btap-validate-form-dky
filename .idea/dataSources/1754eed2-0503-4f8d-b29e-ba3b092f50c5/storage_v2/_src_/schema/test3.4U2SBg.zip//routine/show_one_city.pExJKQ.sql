create
    definer = root@localhost procedure show_one_city(IN id int)
BEGIN 
SELECT * FROM city where city.id = id;
END;

