create
    definer = root@localhost procedure insert_new_city(IN city_name varchar(100), IN nation varchar(100),
                                                       IN area double, IN danso bigint, IN gdp double,
                                                       IN description text)
BEGIN 
INSERT INTO city(city_name,nation,area,danso,gdp,description) VALUES (city_name,nation,area,danso,gdp,description);
END;

